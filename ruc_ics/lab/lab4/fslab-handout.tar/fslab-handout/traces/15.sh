cd mnt
for ((i=0;i<128;++i)); do
	mkdir dir
	cd dir
	done
