cd mnt
mkdir dir1
mkdir dir2
cd dir1
mkdir dir1-1
mkdir dir1-2
ls
cd ..
ls
mv dir1 dir2/dir2-1
ls
cd dir2
ls
cd dir2-1
ls
cd ../..
mv dir2/dir2-1/dir1-1 ./
ls
cd dir2/dir2-1
ls
