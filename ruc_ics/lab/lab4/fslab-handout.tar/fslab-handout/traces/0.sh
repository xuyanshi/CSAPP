cd mnt
