cd mnt
touch file1
touch file2
ls
touch abcdefghijklmnopqrstuvwx
ls
