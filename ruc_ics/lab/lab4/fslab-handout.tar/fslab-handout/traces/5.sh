cd mnt
mkdir dir1
cd dir1
mkdir dir2
cd ..
mkdir dir3
ls
rm -r dir1
ls
rm -r dir3
ls
mkdir dir1
mkdir dir3
ls
cd dir1
ls

