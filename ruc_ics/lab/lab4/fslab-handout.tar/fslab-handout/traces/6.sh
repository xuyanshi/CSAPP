cd mnt
touch file1
touch file2
touch picture
ls
rm picture
ls
rm file*
ls
touch file1
ls
